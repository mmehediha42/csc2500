#include <iostream>

int get_rounds() {
  std::cout << "How many rounds of craps do you want to play? ";
  int rounds = 0;
  std::cin >> rounds;
  return rounds;
}
