#ifndef CRAPS_CONST_H
#define CRAPS_CONST_H
const int WIN = 0;
const int LOSE = 1;
const int POINT = 3;
const int NOTHING = 4;
#endif
