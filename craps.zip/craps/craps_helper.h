#ifndef CRAPS_HELPER_H
#define CRAPS_HELPER_H
int roll_pair();
#endif
