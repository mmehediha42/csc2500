#include "craps_game.h"
#include "craps_helper.h"
#include "craps_const.h"
#include <iostream>
#include <cassert>

void play_rounds(int rounds, int &wins) {
  wins = 0;
  for (int round = 0; round < rounds; round++) {
    int roll;
    int results = toss_opening_roll(roll);
    std::cout << "Round " << round+1 << " : " << roll;
    int point = -1;
    if (results == POINT) {
      point = roll;     
      do {
        results = toss_roll(roll, point);
        std::cout << "*" << roll;
      } while (results == NOTHING);
    }
    if (results == WIN) {
      wins++;
      std::cout << " : WIN!" << std::endl;
    } else {
      std::cout << " : LOSE" << std::endl;
    }
  }
}



int toss_opening_roll(int &roll) {
  roll = roll_pair();
  switch (roll) {
  case 7: case 11:
    return WIN;
  case 2: case 3: case 12:
    return LOSE;
  default:
    return POINT;
  }
}

int toss_roll(int &roll, int point) {
  roll = roll_pair();
  assert(point != -1);
  if (roll == 7) {
    return LOSE;
  } else if (roll == point) {
    return WIN;
  } else {
    return NOTHING;
  }
}
