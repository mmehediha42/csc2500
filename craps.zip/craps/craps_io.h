#ifndef CRAPS_IO_H
#define CRAPS_IO_H
int get_rounds();
#endif
