#include <iostream>
#include <cstdlib>

#include "craps_game.h"
#include "craps_io.h"


int main() {
  srand(time(0));
  int rounds = get_rounds();
  int wins = 0;
  play_rounds(rounds, wins);
  std::cout << "Rounds: " << rounds << ", Wins: " << wins << std::endl;
}


