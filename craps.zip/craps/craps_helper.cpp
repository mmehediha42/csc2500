#include <cstdlib>

int roll_pair() {
    return ((rand() % 6) + 1) + ((rand() % 6) + 1);
}
