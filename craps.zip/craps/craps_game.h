#ifndef CRAPS_GAME_H
#define CRAPS_GAME_H
void play_rounds(int rounds, int &wins);
int toss_opening_roll(int &roll);
int toss_roll(int &roll, int point);
#endif
